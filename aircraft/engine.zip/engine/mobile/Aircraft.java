package engine.mobile;

import engine.map.Block;

/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class Aircraft extends MobileElement{

	public Aircraft(Block position) {
		super(position);
	}
	

}
