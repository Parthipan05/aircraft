package engine.mobile;

import engine.map.Block;

/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class Missile extends MobileElement {

	public Missile(Block position) {
		super(position);
	}

}
