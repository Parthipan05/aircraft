package engine.mobile;

import engine.map.Block;

/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class Bomb extends MobileElement {

	public Bomb(Block position) {
		super(position);
	}

}
