package engine.mobile;

import engine.map.Block;

/**
 * Copyright SEDAMOP - Software Engineering
 * 
 * @author tianxiao.liu@cyu.fr
 *
 */
public class Enemy extends MobileElement{

	public Enemy(Block position) {
		super(position);
	}
	

}
